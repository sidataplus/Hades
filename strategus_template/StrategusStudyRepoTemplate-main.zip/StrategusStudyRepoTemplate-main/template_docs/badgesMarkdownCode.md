Badges Markdown Code
====================

## Repo Created

`<img src="https://img.shields.io/badge/Study%20Status-Repo%20Created-lightgray.svg" alt="Study Status: Repo Created">`

## Started

`<img src="https://img.shields.io/badge/Study%20Status-Started-blue.svg" alt="Study Status: Started">`

## Design Finalized

`<img src="https://img.shields.io/badge/Study%20Status-Design%20Finalized-brightgreen.svg" alt="Study Status: Design Finalized">` 

## Results Available

`<img src="https://img.shields.io/badge/Study%20Status-Results%20Available-yellow.svg" alt="Study Status: Results Available">` 

## Complete

`<img src="https://img.shields.io/badge/Study%20Status-Complete-orange.svg" alt="Study Status: Complete">`

## Suspended

`<img src="https://img.shields.io/badge/Study%20Status-Suspended-red.svg" alt="Study Status: Suspended">`